#include <iostream>

using namespace std;

int main() {
    // T?i ?u h�a lu?ng I/O cho C++
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    // CH� �: N?u h? th?ng ch?m c?a tr??ng b?n (vd: Themis) y�u c?u
    // ??c file v?t l�, h�y b? comment 2 d�ng d??i ?�y v� s?a l?i t�n file cho ?�ng ??.
    // freopen("INPUT.TXT", "r", stdin);
    // freopen("OUTPUT.TXT", "w", stdout);

    long long n, m, p;

    // X? l� n?p li�n t?c cho ??n EOF ?? ch?ng l?i tr�n c�c b? test g?p (Hidden Multitest)
    while (cin >> n >> m >> p) {
        long long K = 0;

        // ??m s? l??ng ph?n t? "x?u" (c� ph?n d? l� p)
        if (n >= p) {
            K = (n - p) / m + 1;
        }

        // Tr? v? thu?n t�y c�ng th?c to�n h?c, kh�ng t? � b?t edge case v� nghi?m
        cout << K + 1 << "\n";
    }
    
    return 0;
}